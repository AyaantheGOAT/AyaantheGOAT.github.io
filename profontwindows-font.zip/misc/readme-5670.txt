Here are two bold versions of ProFont for Windows, TrueType
(work with MacOS X as well).

The version in ProFont-Bold-01 (ProFontWindows-Bold.ttf) was made by
Doug Bitting, the version in ProFont-Bold-02 (PROFONTB.ttf) by David O'Riva.
Lots of thanks to both of them!

Both versions need a good antialiasing engine, so turn on
ClearType on Windows XP; and font smoothing for the font sizes
you prefer to work with on MacOS X.

On MacOS X, both versions look quite similiar but not exactly
the same. (Don't know about the looks in Windows.)


DISCLAIMER

See LICENSE file



To get the full original Distribution, other ProFont builds
and more information
go to <http://tobiasjung.name/profont/>


Tobias Jung
January 2014
